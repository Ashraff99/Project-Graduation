package com.example.side.ui.setting;

import androidx.lifecycle.ViewModel;

public class SettingViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}