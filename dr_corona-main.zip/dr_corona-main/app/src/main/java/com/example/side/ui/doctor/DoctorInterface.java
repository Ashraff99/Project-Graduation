package com.example.side.ui.doctor;

public interface DoctorInterface {
    void getAdapterPosition(int position);
}
