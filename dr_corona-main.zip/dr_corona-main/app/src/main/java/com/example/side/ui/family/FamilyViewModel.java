package com.example.side.ui.family;

import androidx.lifecycle.ViewModel;

public class FamilyViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}