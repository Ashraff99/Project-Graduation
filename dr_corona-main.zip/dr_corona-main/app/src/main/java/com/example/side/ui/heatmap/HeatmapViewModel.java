package com.example.side.ui.heatmap;

import androidx.lifecycle.ViewModel;

public class HeatmapViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}