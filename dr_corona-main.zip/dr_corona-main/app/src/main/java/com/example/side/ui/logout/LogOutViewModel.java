package com.example.side.ui.logout;

import androidx.lifecycle.ViewModel;

public class LogOutViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}