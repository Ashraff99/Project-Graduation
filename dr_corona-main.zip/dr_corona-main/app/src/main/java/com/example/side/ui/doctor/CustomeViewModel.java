package com.example.side.ui.doctor;

import androidx.lifecycle.ViewModel;

public class CustomeViewModel  extends ViewModel {
}
