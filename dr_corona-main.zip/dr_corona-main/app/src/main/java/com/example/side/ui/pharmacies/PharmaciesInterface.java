package com.example.side.ui.pharmacies;

public interface PharmaciesInterface {
    void getPharmacyPosition(int position);
}
