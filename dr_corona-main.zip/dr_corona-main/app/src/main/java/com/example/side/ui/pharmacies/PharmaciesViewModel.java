package com.example.side.ui.pharmacies;

import androidx.lifecycle.ViewModel;

public class PharmaciesViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}