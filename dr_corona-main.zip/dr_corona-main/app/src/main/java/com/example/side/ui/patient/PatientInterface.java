package com.example.side.ui.patient;

public interface PatientInterface {
    void getPatientPosition(int position);
}
