package com.example.side.ui.hospital;

import androidx.lifecycle.ViewModel;

public class HospitalViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
