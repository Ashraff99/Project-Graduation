package com.example.side.ui.hospital;

public interface HospitalInterface {
    void getHospitalPosition(int position);
}
