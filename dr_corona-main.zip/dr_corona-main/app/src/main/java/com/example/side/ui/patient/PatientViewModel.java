package com.example.side.ui.patient;

import androidx.lifecycle.ViewModel;

public class PatientViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}