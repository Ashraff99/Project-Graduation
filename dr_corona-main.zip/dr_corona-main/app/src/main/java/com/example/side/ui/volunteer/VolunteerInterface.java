package com.example.side.ui.volunteer;

public interface VolunteerInterface {
    void getVolunteerPosition(int position);
}
