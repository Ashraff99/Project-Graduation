package com.example.side.ui.qr;

import androidx.lifecycle.ViewModel;

public class QrViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}